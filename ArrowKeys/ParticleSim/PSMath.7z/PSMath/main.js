/**@type {HTMLCanvasElement} */
const can = document.getElementById("can");
const ctx = can.getContext("2d");
const nob = new NobsinCtx(ctx);

const demo = document.querySelector("#demo");

const black = [0,0,0,255];
const red = [255,0,0,255];

let objs = [];
for(let i = 0; i < 1; i++){
    objs.push([
        nob.width*0.75,
        nob.height*0.25,
        0,0
    ]);
}

let cx = nob.centerX;
let cy = nob.centerY;

function update(){
    requestAnimationFrame(update);

    nob.updateStart();

    nob.setPixel(nob.centerX,nob.centerY,red);
    
    for(let i = 0; i < objs.length; i++){
        let o = objs[i];
        
        o[0] += o[2];
        o[1] += o[3];

        if(i == 0){
            //cx and cy be previous particle
            let ang = Math.atan2(o[1]-cy,o[0]-cx);
            demo.textContent = (ang*180/Math.PI).toFixed(2);
        }
        
        nob.setPixel(o[0],o[1],black);
    }
    nob.updateEnd();
}
update();